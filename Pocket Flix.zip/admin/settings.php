<?php include('../common/config.php'); 
if(!isset($_SESSION['admin'])){ header('Location: login.php'); exit(); }
if (isset($_POST['up'])) {
    $an = clean($_POST['an']);
    if (!empty($_FILES["l"]["name"])) {
        $logo_name = "app_logo.png";
        move_uploaded_file($_FILES["l"]["tmp_name"], "../uploads/".$logo_name);
        $path = "uploads/".$logo_name;
        mysqli_query($conn, "UPDATE settings SET app_logo='$path' WHERE id=1");
    }
    mysqli_query($conn, "UPDATE settings SET app_name='$an' WHERE id=1");
    header('Location: settings.php');
}
?>
<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-black text-white p-6"><a href="index.php" class="text-red-600 font-bold mb-6 block italic">Back</a>
    <form method="POST" enctype="multipart/form-data" class="bg-gray-900 p-6 rounded-3xl space-y-6 shadow-2xl border border-white/5">
        <h2 class="text-xl font-bold uppercase italic text-red-600">App Branding</h2>
        <div><label class="text-[10px] text-gray-500 font-bold uppercase ml-1">App Name</label>
        <input type="text" name="an" value="<?php echo $settings['app_name']; ?>" class="w-full bg-black p-4 rounded-2xl border border-gray-700 outline-none"></div>
        <div><label class="text-[10px] text-gray-500 font-bold uppercase ml-1">Update Logo</label>
        <input type="file" name="l" accept="image/*" class="w-full bg-black p-4 rounded-2xl border border-gray-700 text-xs"></div>
        <button name="up" class="w-full bg-red-600 py-4 rounded-2xl font-black">SAVE CHANGES</button>
    </form>
</body></html>