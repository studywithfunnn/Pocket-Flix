<?php include('../common/config.php'); 
if(!isset($_SESSION['admin'])){ header('Location: login.php'); exit(); }
$m_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM movies"));
$c_count = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM categories"));
?>
<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></head>
<body class="bg-black text-white p-6 pb-20">
    <div class="flex justify-between items-center mb-10"><h1 class="text-2xl font-black italic text-red-600 uppercase">Admin Panel</h1><a href="logout.php" class="text-red-500"><i class="fa-solid fa-power-off"></i></a></div>
    <div class="grid grid-cols-2 gap-4 mb-10">
        <div class="bg-gray-900 p-6 rounded-3xl border border-white/5"><p class="text-[10px] font-bold text-gray-500 uppercase mb-1">Movies</p><h2 class="text-3xl font-black italic"><?php echo $m_count; ?></h2></div>
        <div class="bg-gray-900 p-6 rounded-3xl border border-white/5"><p class="text-[10px] font-bold text-gray-500 uppercase mb-1">Categories</p><h2 class="text-3xl font-black italic"><?php echo $c_count; ?></h2></div>
    </div>
    <div class="space-y-3">
        <a href="movies.php" class="block bg-gray-900 p-5 rounded-2xl border border-white/5 flex justify-between items-center"><span class="font-bold uppercase text-xs">Manage Movies</span><i class="fa-solid fa-film text-red-600"></i></a>
        <a href="categories.php" class="block bg-gray-900 p-5 rounded-2xl border border-white/5 flex justify-between items-center"><span class="font-bold uppercase text-xs">Manage Categories</span><i class="fa-solid fa-list text-red-600"></i></a>
        <a href="banners.php" class="block bg-gray-900 p-5 rounded-2xl border border-white/5 flex justify-between items-center"><span class="font-bold uppercase text-xs">Manage Banners</span><i class="fa-solid fa-image text-red-600"></i></a>
        <a href="settings.php" class="block bg-gray-900 p-5 rounded-2xl border border-red-600/30 flex justify-between items-center"><span class="font-bold uppercase text-xs">App Settings</span><i class="fa-solid fa-gear text-red-600"></i></a>
    </div>
</body></html>