<?php include('../common/config.php'); 
if(!isset($_SESSION['admin'])){ header('Location: login.php'); exit(); }
if(isset($_GET['del'])){ $id=intval($_GET['del']); mysqli_query($conn,"DELETE FROM movies WHERE id=$id"); header('Location: movies.php'); }

if(isset($_POST['save'])){
    $t = clean($_POST['t']); $d = clean($_POST['d']); $c = intval($_POST['c']); $w = clean($_POST['w']); $r = clean($_POST['r']); $y = clean($_POST['y']);
    $fn = time()."_".basename($_FILES["f"]["name"]);
    if(move_uploaded_file($_FILES["f"]["tmp_name"], "../uploads/".$fn)){
        $path = "uploads/".$fn;
        mysqli_query($conn, "INSERT INTO movies (title,poster_url,description,rating,release_year,category_id,watch_link) VALUES ('$t','$path','$d','$r','$y','$c','$w')");
    }
}
?>
<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"></head>
<body class="bg-black text-white p-4 pb-24"><a href="index.php" class="text-red-600 font-bold mb-4 block italic">Back</a>
    <form method="POST" enctype="multipart/form-data" class="bg-gray-900 p-6 rounded-3xl space-y-4 shadow-2xl border border-white/5">
        <h2 class="text-xl font-bold uppercase italic text-red-600">Add Movie</h2>
        <input type="text" name="t" placeholder="Title" class="w-full bg-black p-4 rounded-2xl border border-gray-700 outline-none" required>
        <input type="file" name="f" class="w-full bg-black p-4 rounded-2xl border border-gray-700 text-xs" required>
        <textarea name="d" placeholder="Desc" class="w-full bg-black p-4 rounded-2xl border border-gray-700 h-24 outline-none"></textarea>
        <div class="grid grid-cols-2 gap-4">
            <input type="text" name="r" placeholder="Rating (8.5)" class="bg-black p-4 rounded-2xl border border-gray-700 outline-none">
            <input type="number" name="y" placeholder="Year (2024)" class="bg-black p-4 rounded-2xl border border-gray-700 outline-none">
        </div>
        <select name="c" class="w-full bg-black p-4 rounded-2xl border border-gray-700 outline-none">
            <?php $cs=mysqli_query($conn,"SELECT*FROM categories"); while($row=mysqli_fetch_assoc($cs)) echo "<option value='{$row['id']}'>{$row['category_name']}</option>"; ?>
        </select>
        <input type="text" name="w" placeholder="modi.mp4" class="w-full bg-black p-4 rounded-2xl border border-gray-700 outline-none" required>
        <button name="save" class="w-full bg-red-600 py-4 rounded-2xl font-black">UPLOAD MOVIE</button>
    </form>
    <div class="mt-8 space-y-3">
        <?php $ml = mysqli_query($conn, "SELECT * FROM movies ORDER BY id DESC");
        while($m = mysqli_fetch_assoc($ml)): ?>
        <div class="bg-gray-900 p-3 rounded-2xl border border-white/5 flex items-center justify-between shadow-lg">
            <div class="flex items-center gap-4"><img src="../<?php echo $m['poster_url']; ?>" class="w-12 h-16 object-cover rounded-lg"><div><p class="font-bold text-sm truncate w-40"><?php echo $m['title']; ?></p></div></div>
            <a href="?del=<?php echo $m['id']; ?>" class="text-red-500 p-2"><i class="fa-solid fa-trash"></i></a>
        </div>
        <?php endwhile; ?>
    </div>
</body></html>