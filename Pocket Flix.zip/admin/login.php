<?php include('../common/config.php'); 
if(isset($_POST['l'])){
    $u = clean($_POST['u']); $p = $_POST['p'];
    $a = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin WHERE username='$u'"));
    if($a && password_verify($p, $a['password'])){ $_SESSION['admin']=$a['id']; header('Location: index.php'); exit(); }
    else { $err = "Galat Password!"; }
}
?>
<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-black text-white flex items-center justify-center h-screen p-6">
<form method="POST" class="w-full max-w-sm bg-gray-900 p-8 rounded-3xl border border-gray-800 shadow-2xl">
<h2 class="text-3xl font-black text-red-600 mb-8 text-center italic">ADMIN</h2>
<?php if(isset($err)) echo "<p class='text-red-500 text-xs text-center mb-4'>$err</p>"; ?>
<input type="text" name="u" placeholder="User" class="w-full bg-black p-4 rounded-xl border border-gray-700 mb-4 outline-none">
<input type="password" name="p" placeholder="Pass" class="w-full bg-black p-4 rounded-xl border border-gray-700 mb-6 outline-none">
<button name="l" class="w-full bg-red-600 py-4 rounded-xl font-bold uppercase">Login</button>
</form></body></html>