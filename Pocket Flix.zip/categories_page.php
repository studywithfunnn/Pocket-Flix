<?php include('common/header.php'); ?>
<div class="p-6 min-h-screen">
    <h2 class="text-2xl font-black italic uppercase mb-8 border-l-4 border-red-600 pl-3">All Categories</h2>
    <div class="grid grid-cols-2 gap-4">
        <?php $cats = mysqli_query($conn, "SELECT * FROM categories ORDER BY category_name ASC");
        while($c = mysqli_fetch_assoc($cats)): ?>
        <a href="category_movies.php?id=<?php echo $c['id']; ?>" class="bg-gray-900 p-8 rounded-3xl border border-white/5 text-center shadow-2xl active:scale-95 transition">
            <i class="fa-solid fa-clapperboard text-red-600 text-3xl mb-3"></i>
            <h3 class="font-bold text-sm uppercase tracking-widest"><?php echo $c['category_name']; ?></h3>
        </a>
        <?php endwhile; ?>
    </div>
</div>
<?php include('common/bottom.php'); ?>