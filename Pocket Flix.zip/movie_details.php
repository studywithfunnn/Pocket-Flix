<?php include('common/header.php'); 
$id = intval($_GET['id']);
$m = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM movies WHERE id=$id"));
$v = $m['watch_link'];
$final_v = (file_exists($v)) ? $v : (file_exists("videos/".$v) ? "videos/".$v : $v);
?>
<div class="relative w-full h-[40vh]">
    <img src="<?php echo $m['poster_url']; ?>" class="w-full h-full object-cover opacity-40">
    <div class="absolute inset-0 bg-gradient-to-t from-black"></div>
</div>
<div class="px-6 -mt-24 relative z-10 text-center">
    <h1 class="text-4xl font-black italic mb-6 uppercase tracking-tighter"><?php echo $m['title']; ?></h1>
    <div class="bg-gray-900 rounded-3xl overflow-hidden border border-white/5 shadow-2xl mb-8">
        <video id="player" controls class="w-full aspect-video bg-black" poster="<?php echo $m['poster_url']; ?>" playsinline>
            <source src="<?php echo $final_v; ?>" type="video/mp4">
        </video>
    </div>
    <div class="text-left space-y-4">
        <p class="text-gray-400 text-sm leading-relaxed"><?php echo $m['description']; ?></p>
        <div class="flex gap-4 text-[10px] font-black text-gray-500 uppercase">
            <span>Rating: <?php echo $m['rating']; ?></span>
            <span>Year: <?php echo $m['release_year']; ?></span>
        </div>
    </div>
</div>
<?php include('common/bottom.php'); ?>