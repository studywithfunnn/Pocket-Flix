<?php include('common/header.php'); ?>
<div class="relative w-full h-[65vh] overflow-x-auto snap-x snap-mandatory flex hide-scroll">
    <?php $bs = mysqli_query($conn, "SELECT banners.*, movies.title FROM banners JOIN movies ON banners.target_movie_id = movies.id");
    while($b = mysqli_fetch_assoc($bs)): ?>
    <div class="min-w-full h-full snap-start relative">
        <img src="<?php echo $b['banner_image_url']; ?>" class="w-full h-full object-cover">
        <div class="absolute inset-0 flix-gradient flex flex-col justify-end p-10 text-center">
            <h2 class="text-3xl font-black mb-4 uppercase italic tracking-tighter"><?php echo $b['title']; ?></h2>
            <a href="movie_details.php?id=<?php echo $b['target_movie_id']; ?>" class="bg-white text-black font-black py-3 px-8 rounded-full mx-auto text-sm tracking-widest">PLAY NOW</a>
        </div>
    </div>
    <?php endwhile; ?>
</div>
<div class="p-4 -mt-12 relative z-10 space-y-10">
    <?php $cs = mysqli_query($conn, "SELECT * FROM categories");
    while($c = mysqli_fetch_assoc($cs)): ?>
    <div>
        <h3 class="text-lg font-black mb-3 uppercase italic tracking-tighter ml-2"><?php echo $c['category_name']; ?></h3>
        <div class="flex gap-4 overflow-x-auto hide-scroll px-2">
            <?php $ms = mysqli_query($conn, "SELECT * FROM movies WHERE category_id={$c['id']} ORDER BY id DESC");
            while($m = mysqli_fetch_assoc($ms)): ?>
            <a href="movie_details.php?id=<?php echo $m['id']; ?>" class="min-w-[135px] active:scale-95 transition">
                <img src="<?php echo $m['poster_url']; ?>" class="h-48 w-full object-cover rounded-2xl border border-white/5 shadow-2xl">
            </a>
            <?php endwhile; ?>
        </div>
    </div>
    <?php endwhile; ?>
</div>
<?php include('common/bottom.php'); ?>