<?php include('common/header.php'); 
if (isset($_POST['update_user'])) { $_SESSION['user_display_name'] = clean($_POST['u_name']); $msg = "✅ Updated!"; }
$u_display = $_SESSION['user_display_name'] ?? "Pocket User";
?>
<div class="p-6 pt-24 min-h-screen flex flex-col items-center">
    <div class="w-24 h-24 bg-red-600 rounded-3xl flex items-center justify-center text-4xl shadow-2xl shadow-red-900/40 mb-6">
        <i class="fa-solid fa-user"></i>
    </div>
    <h2 class="text-xl font-black uppercase italic mb-10 tracking-widest"><?php echo $u_display; ?></h2>

    <form method="POST" class="w-full bg-gray-900 p-6 rounded-3xl border border-white/5 space-y-6">
        <div class="space-y-1">
            <label class="text-[10px] text-gray-500 font-bold ml-1 uppercase">Display Name</label>
            <input type="text" name="u_name" value="<?php echo $u_display; ?>" class="w-full bg-black p-4 rounded-2xl border border-gray-800 outline-none text-sm font-bold">
        </div>
        <button name="update_user" class="w-full bg-white text-black py-4 rounded-2xl font-black text-xs uppercase tracking-widest">Update Profile</button>
    </form>
    <p class="mt-20 text-[8px] font-black uppercase tracking-[5px] text-gray-700">Pocket Flix Premium</p>
</div>
<?php include('common/bottom.php'); ?>