<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) { session_start(); }

$host = '127.0.0.1'; $user = 'root'; $pass = 'root'; $dbname = 'pocket_flix_db';
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) { die("DB Connection Failed"); }

if (!function_exists('clean')) {
    function clean($data) {
        global $conn;
        return mysqli_real_escape_string($conn, htmlspecialchars($data));
    }
}

$settings = ['app_name' => 'POCKETFLIX', 'footer_text' => '© 2024 Pocket Flix', 'app_logo' => ''];
$s_res = mysqli_query($conn, "SELECT * FROM settings WHERE id = 1");
if ($s_res && mysqli_num_rows($s_res) > 0) { $settings = mysqli_fetch_assoc($s_res); }
?>