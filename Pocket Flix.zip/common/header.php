<?php include_once('config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo $settings['app_name']; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background:#000; color:#fff; -webkit-tap-highlight-color:transparent; scrollbar-width:none; overflow-x:hidden; }
        ::-webkit-scrollbar { display:none; }
        .no-select { -webkit-user-select:none; user-select:none; }
        .flix-gradient { background: linear-gradient(to top, #000 15%, transparent 100%); }
    </style>
</head>
<body class="no-select">
    <script>
        document.addEventListener('contextmenu', e => e.preventDefault());
        document.addEventListener('keydown', e => { if(e.ctrlKey && (e.key==='='||e.key==='-'||e.key==='0')) e.preventDefault(); });
    </script>
    <header class="fixed top-0 w-full z-[100] bg-black/60 backdrop-blur-lg p-4 flex justify-between items-center border-b border-white/5">
        <a href="index.php">
            <?php if(!empty($settings['app_logo']) && file_exists($settings['app_logo'])): ?>
                <img src="<?php echo $settings['app_logo']; ?>?v=<?php echo time(); ?>" class="h-8 object-contain">
            <?php else: ?>
                <h1 class="text-red-600 font-black text-2xl italic tracking-tighter uppercase"><?php echo $settings['app_name']; ?></h1>
            <?php endif; ?>
        </a>
        <a href="search.php" class="text-white text-xl"><i class="fa-solid fa-magnifying-glass"></i></a>
    </header>
    <div class="pt-16">