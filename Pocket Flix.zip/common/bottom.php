<div class="h-24"></div>
    <nav class="fixed bottom-0 w-full bg-black/95 backdrop-blur-xl border-t border-white/5 flex justify-around items-center py-4 z-[100] pb-8">
        <a href="index.php" class="flex flex-col items-center gap-1"><i class="fa-solid fa-house text-xl text-gray-500 hover:text-red-600"></i><span class="text-[10px] font-bold uppercase">Home</span></a>
        <a href="categories_page.php" class="flex flex-col items-center gap-1"><i class="fa-solid fa-layer-group text-xl text-gray-500 hover:text-red-600"></i><span class="text-[10px] font-bold uppercase">Category</span></a>
        <a href="search.php" class="flex flex-col items-center gap-1"><i class="fa-solid fa-magnifying-glass text-xl text-gray-500 hover:text-red-600"></i><span class="text-[10px] font-bold uppercase">Search</span></a>
        <a href="profile.php" class="flex flex-col items-center gap-1"><i class="fa-solid fa-circle-user text-xl text-gray-500 hover:text-red-600"></i><span class="text-[10px] font-bold uppercase">Profile</span></a>
    </nav>
</body></html>