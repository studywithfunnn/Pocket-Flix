<?php include('common/header.php'); 
$id = intval($_GET['id']);
$cn = mysqli_fetch_assoc(mysqli_query($conn, "SELECT category_name FROM categories WHERE id=$id"));
?>
<div class="p-4 min-h-screen">
    <div class="flex items-center gap-4 mb-8">
        <a href="categories_page.php" class="text-red-600 text-2xl"><i class="fa-solid fa-arrow-left"></i></a>
        <h2 class="text-2xl font-black italic uppercase"><?php echo $cn['category_name'] ?? 'Movies'; ?></h2>
    </div>
    <div class="grid grid-cols-3 gap-3">
        <?php $res = mysqli_query($conn, "SELECT * FROM movies WHERE category_id=$id ORDER BY id DESC");
        while($m = mysqli_fetch_assoc($res)): ?>
        <a href="movie_details.php?id=<?php echo $m['id']; ?>" class="block active:scale-95 transition">
            <img src="<?php echo $m['poster_url']; ?>" class="h-44 w-full object-cover rounded-xl border border-white/5">
            <p class="text-[10px] mt-2 truncate text-center font-bold text-gray-400"><?php echo $m['title']; ?></p>
        </a>
        <?php endwhile; ?>
    </div>
</div>
<?php include('common/bottom.php'); ?>