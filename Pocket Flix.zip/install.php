<?php
$c = mysqli_connect('127.0.0.1', 'root', 'root');
$sql = "CREATE DATABASE IF NOT EXISTS pocket_flix_db; USE pocket_flix_db;
CREATE TABLE IF NOT EXISTS admin (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50), password VARCHAR(255));
CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, category_name VARCHAR(100));
CREATE TABLE IF NOT EXISTS movies (id INT AUTO_INCREMENT PRIMARY KEY, title VARCHAR(255), poster_url TEXT, description TEXT, rating VARCHAR(10), release_year INT, category_id INT, watch_link TEXT);
CREATE TABLE IF NOT EXISTS banners (id INT AUTO_INCREMENT PRIMARY KEY, banner_image_url TEXT, target_movie_id INT);
CREATE TABLE IF NOT EXISTS settings (id INT PRIMARY KEY, app_name VARCHAR(100), footer_text VARCHAR(255), app_logo TEXT);";
mysqli_multi_query($c, $sql);
do{mysqli_store_result($c);}while(mysqli_next_result($c));
$p = password_hash('admin123', PASSWORD_DEFAULT);
mysqli_query($c, "INSERT IGNORE INTO admin (id,username,password) VALUES (1,'admin','$p')");
mysqli_query($c, "INSERT IGNORE INTO settings (id,app_name,footer_text) VALUES (1,'POCKETFLIX','© 2024 Pocket Flix')");
echo "✅ Pocket Flix Installed! <a href='index.php'>Go to Home</a>";
?>